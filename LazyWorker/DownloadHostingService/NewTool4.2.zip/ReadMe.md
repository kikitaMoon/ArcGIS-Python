# What's New in Download Hosting Feature Service 4.2 ?

- 1. Support Customizing the Max Record Count.  Using the max record count reading from feature service by default.
- 2. Optimizing the Message information of the Tool.

**Strongly recommand installing ArcGIS Desktop Backgroung Processing 64-bit Package before using this tool.**
